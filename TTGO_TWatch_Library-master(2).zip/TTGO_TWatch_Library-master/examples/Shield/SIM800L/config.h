
// => Hardware select
// #define LILYGO_WATCH_2019_WITH_TOUCH
//#define LILYGO_WATCH_2019_NO_TOUCH
//#define LILYGO_WATCH_BLOCK            //Cannot be viewed from the monitor without a screen



//NOT SUPPORT ...
// #define LILYGO_WATCH_2020_V1
//NOT SUPPORT ...


// => Function select
#define LILYGO_WATCH_HAS_MOTOR       //To use MOTOR, you need to enable the macro MOTOR
#define LILYGO_WATCH_HAS_SIM800L    //To use SIM800L, you need to enable the macro SIM800L

#include <LilyGoWatch.h>