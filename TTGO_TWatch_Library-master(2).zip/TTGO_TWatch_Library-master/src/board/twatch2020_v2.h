#pragma once

#define TFT_WIDTH                   240
#define TFT_HEIGHT                  240

#define TWATCH_TFT_MISO             (gpio_num_t)0
#define TWATCH_TFT_MOSI             (gpio_num_t)19
#define TWATCH_TFT_SCLK             (gpio_num_t)18
#define TWATCH_TFT_CS               (gpio_num_t)5
#define TWATCH_TFT_DC               (gpio_num_t)27
#define TWATCH_TFT_RST              (gpio_num_t)-1
#define TWATCH_TFT_BL               (gpio_num_t)12

#define TOUCH_SDA                   23
#define TOUCH_SCL                   32
#define TOUCH_INT                   38

#define SEN_SDA                     21
#define SEN_SCL                     22

#define RTC_INT                     37
#define AXP202_INT                  35
#define BMA423_INT1                 39

#define TWATCH_2020_IR_PIN          16

#define TWATCH_GPS_1PPS             34
#define TWATCH_GPS_RXD              26
#define TWATCH_GPS_TXD              25
#define TWATCH_GPS_WAKE             33