package com.thatproject.androidesp32btrecordingapp;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
