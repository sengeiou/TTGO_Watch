#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/sil0/Workspace/01_Dev_Libraries/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/sil0/Workspace/00_Github/Youtube_Contents/Esp32_Flutter_BLE_LocalNoti/flutter_blue_localnotify"
export "FLUTTER_TARGET=/Users/sil0/Workspace/00_Github/Youtube_Contents/Esp32_Flutter_BLE_LocalNoti/flutter_blue_localnotify/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "FLUTTER_FRAMEWORK_DIR=/Users/sil0/Workspace/01_Dev_Libraries/flutter/bin/cache/artifacts/engine/ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "TRACK_WIDGET_CREATION=true"
